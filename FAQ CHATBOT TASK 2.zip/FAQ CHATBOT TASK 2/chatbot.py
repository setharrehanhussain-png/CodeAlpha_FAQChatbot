
import json
import re
from difflib import SequenceMatcher
from pathlib import Path


class FAQChatbot:
    def __init__(self, faq_file="faqs.json"):
        self.faq_file = Path(__file__).parent / faq_file
        self.faqs = self.load_faqs()

    def load_faqs(self):
        try:
            with open(self.faq_file, "r", encoding="utf-8") as file:
                data = json.load(file)
            return data.get("faqs", [])
        except (OSError, json.JSONDecodeError):
            return []

    def normalize(self, text):
        text = text.lower().strip()
        text = re.sub(r"[^\w\s]", " ", text)
        return re.sub(r"\s+", " ", text)

    def get_response(self, user_message):
        message = self.normalize(user_message)

        if not message:
            return "Please enter a question so I can help you."

        greetings = {"hi", "hello", "hey", "good morning", "good afternoon", "good evening"}

        if message in greetings:
            return "Hello! Welcome to the FAQ Chatbot. How can I help you today?"

        best_match = None
        best_score = 0

        message_words = set(message.split())

        for faq in self.faqs:
            question = self.normalize(faq.get("question", ""))
            answer = faq.get("answer", "")
            question_words = set(question.split())

            if not question or not answer:
                continue

            if message == question:
                return answer

            common_words = message_words & question_words
            overlap = len(common_words) / max(len(question_words), 1)
            similarity = SequenceMatcher(None, message, question).ratio()
            score = max(overlap, similarity)

            if question in message or message in question:
                score = max(score, 0.85)

            if score > best_score:
                best_score = score
                best_match = answer

        if best_match and best_score >= 0.45:
            return best_match

        return (
            "I'm sorry, I couldn't find an answer to that question. "
            "Try asking about Python, artificial intelligence, internships, "
            "or support."
        )
