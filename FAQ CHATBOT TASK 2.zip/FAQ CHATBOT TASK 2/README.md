# CodeAlpha FAQ Chatbot

A Python-based Frequently Asked Questions (FAQ) Chatbot developed as **Task 2 of my CodeAlpha Internship**. The application provides an interactive desktop interface where users can ask questions and receive answers from a predefined FAQ knowledge base.

## Project Overview

The FAQ Chatbot is designed to answer common questions about Python, artificial intelligence, programming, internships, and general learning. It uses text normalization, keyword overlap, and similarity matching to identify relevant questions and return appropriate responses.

The application features a graphical user interface built with Python's Tkinter library.

## Features

- Interactive desktop chat interface
- Automated FAQ-based question answering
- Text normalization for flexible question matching
- Similarity-based matching for related questions
- Friendly greeting responses
- Fallback responses for questions outside the FAQ database
- Suggested questions for quick interaction
- Message timestamps
- Clear Chat functionality
- Send messages using the Enter key
- Empty-input handling
- JSON-based FAQ knowledge base

## Technologies Used

- **Python** — application logic and response processing
- **Tkinter** — graphical user interface
- **JSON** — FAQ data storage
- **Regular Expressions** — text normalization
- **Difflib** — text similarity matching

## Project Structure

```text
FAQ CHATBOT TASK 2/
├── app.py
├── chatbot.py
├── faqs.json
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.10 or later recommended
- Tkinter support in your Python installation

The project uses Python's standard library and does not require a paid API or external AI service.

## Installation and Setup

### 1. Install Python

Download Python from the official website:

https://www.python.org/downloads/

During installation on Windows, enable the option to add Python to PATH if available.

### 2. Open the Project Folder

Open the project folder in Visual Studio Code.

### 3. Run the Application

Open the integrated terminal and execute:

```powershell
py app.py
```

The FAQ Chatbot window should open.

## How to Use

1. Launch the application.
2. Enter a question in the message field.
3. Click **SEND** or press **Enter**.
4. Read the chatbot's response.
5. Use the suggested questions to explore common topics.
6. Click **CLEAR CHAT** to reset the conversation.

## FAQ Knowledge Base

The chatbot loads its predefined questions and answers from `faqs.json`. You can expand its knowledge base by adding more question-and-answer entries using the existing JSON structure.

The matching logic is implemented in `chatbot.py`, while `app.py` manages the graphical interface.

## Testing

The application was tested for the following behaviors:

- Correct responses to known questions
- Greeting recognition
- Fallback responses for unknown questions
- Empty-input handling
- Clear Chat functionality
- Enter-key message submission
- Suggested-question buttons

All of these tests were completed successfully.

## Learning Outcomes

Through this project, I gained practical experience in:

- Python application development
- GUI design using Tkinter
- JSON data handling
- Text processing and similarity matching
- Event-driven programming
- Error handling and application testing

## Internship Acknowledgment

This project was developed as part of my CodeAlpha Internship.

I am thankful to the **CodeAlpha Team** for providing this learning opportunity and helping me strengthen my programming and software development skills through practical projects.

## Future Improvements

- Expand the FAQ knowledge base
- Add category-based questions
- Improve matching for more complex queries
- Add conversation export functionality
- Explore optional AI-powered responses

---

**Project:** FAQ Chatbot  
**Internship:** CodeAlpha — Task 2  
**Language:** Python  
**Interface:** Tkinter
