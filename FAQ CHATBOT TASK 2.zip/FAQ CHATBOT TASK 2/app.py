
import tkinter as tk
from tkinter import ttk
from datetime import datetime
from chatbot import FAQChatbot


class FAQChatbotApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CodeAlpha | FAQ Chatbot")
        self.root.geometry("900x700")
        self.root.minsize(700, 550)
        self.root.configure(bg="#F3F6FB")

        self.chatbot = FAQChatbot()
        self.colors = {
            "background": "#F3F6FB",
            "panel": "#FFFFFF",
            "primary": "#2457C5",
            "text": "#172033",
            "muted": "#68758A",
            "user": "#DCE8FF",
            "bot": "#E9F7EF",
            "border": "#DCE3ED"
        }

        self.build_ui()
        self.add_message(
            "bot",
            "Hello! Welcome to the FAQ Chatbot. Ask me about Python, AI, "
            "internships, or programming."
        )

    def build_ui(self):
        header = tk.Frame(self.root, bg=self.colors["primary"], height=85)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(
            header,
            text="FAQ CHATBOT",
            font=("Segoe UI", 19, "bold"),
            bg=self.colors["primary"],
            fg="white"
        ).pack(anchor="w", padx=24, pady=(15, 0))

        tk.Label(
            header,
            text="CodeAlpha Internship • Task 2",
            font=("Segoe UI", 10),
            bg=self.colors["primary"],
            fg="#E4ECFF"
        ).pack(anchor="w", padx=25)

        main = tk.Frame(self.root, bg=self.colors["background"])
        main.pack(fill="both", expand=True, padx=20, pady=16)

        self.chat_frame = tk.Frame(
            main,
            bg=self.colors["panel"],
            highlightbackground=self.colors["border"],
            highlightthickness=1
        )
        self.chat_frame.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(
            self.chat_frame,
            bg=self.colors["panel"],
            highlightthickness=0
        )
        scrollbar = ttk.Scrollbar(
            self.chat_frame,
            orient="vertical",
            command=self.canvas.yview
        )
        self.messages_frame = tk.Frame(
            self.canvas,
            bg=self.colors["panel"]
        )

        self.messages_window = self.canvas.create_window(
            (0, 0),
            window=self.messages_frame,
            anchor="nw"
        )
        self.messages_frame.bind(
            "<Configure>",
            lambda event: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(
                self.messages_window,
                width=event.width
            )
        )
        self.canvas.configure(yscrollcommand=scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        scrollbar.pack(side="right", fill="y", pady=8, padx=(0, 5))

        suggestions = tk.Frame(main, bg=self.colors["background"])
        suggestions.pack(fill="x", pady=(12, 8))

        tk.Label(
            suggestions,
            text="TRY ASKING",
            font=("Segoe UI", 9, "bold"),
            bg=self.colors["background"],
            fg=self.colors["muted"]
        ).pack(anchor="w", pady=(0, 6))

        suggestion_row = tk.Frame(
            suggestions,
            bg=self.colors["background"]
        )
        suggestion_row.pack(fill="x")

        for question in [
            "What is Python?",
            "What is AI?",
            "How can I apply for an internship?"
        ]:
            tk.Button(
                suggestion_row,
                text=question,
                command=lambda q=question: self.send_suggestion(q),
                font=("Segoe UI", 9),
                bg="white",
                fg=self.colors["primary"],
                activebackground="#E4ECFF",
                relief="solid",
                bd=1,
                padx=8,
                pady=6,
                cursor="hand2"
            ).pack(side="left", padx=(0, 7))

        input_panel = tk.Frame(
            main,
            bg=self.colors["panel"],
            highlightbackground=self.colors["border"],
            highlightthickness=1
        )
        input_panel.pack(fill="x")

        self.entry = tk.Entry(
            input_panel,
            font=("Segoe UI", 11),
            relief="flat",
            bg="white",
            fg=self.colors["text"]
        )
        self.entry.pack(
            side="left",
            fill="x",
            expand=True,
            padx=(12, 5),
            pady=13,
            ipady=7
        )
        self.entry.bind("<Return>", lambda event: self.send_message())

        tk.Button(
            input_panel,
            text="SEND",
            command=self.send_message,
            font=("Segoe UI", 10, "bold"),
            bg=self.colors["primary"],
            fg="white",
            activebackground="#19439D",
            activeforeground="white",
            relief="flat",
            padx=20,
            pady=9,
            cursor="hand2"
        ).pack(side="left", padx=5, pady=7)

        tk.Button(
            input_panel,
            text="CLEAR CHAT",
            command=self.clear_chat,
            font=("Segoe UI", 9),
            bg="#EDF1F7",
            fg=self.colors["text"],
            relief="flat",
            padx=10,
            pady=9,
            cursor="hand2"
        ).pack(side="left", padx=(4, 10), pady=7)

        tk.Label(
            self.root,
            text="Python • Tkinter • FAQ Matching",
            font=("Segoe UI", 9),
            bg=self.colors["background"],
            fg=self.colors["muted"]
        ).pack(pady=(0, 8))

        self.entry.focus_set()

    def add_message(self, sender, message):
        outer = tk.Frame(self.messages_frame, bg=self.colors["panel"])
        outer.pack(fill="x", padx=12, pady=7)

        is_user = sender == "user"
        label = "You" if is_user else "FAQ Bot"
        bubble_color = self.colors["user"] if is_user else self.colors["bot"]
        side = "e" if is_user else "w"

        bubble = tk.Frame(outer, bg=bubble_color)
        bubble.pack(anchor=side, padx=(45, 0) if is_user else (0, 45))

        tk.Label(
            bubble,
            text=label,
            font=("Segoe UI", 9, "bold"),
            bg=bubble_color,
            fg=self.colors["primary"] if is_user else "#20734A"
        ).pack(anchor="w", padx=11, pady=(7, 0))

        tk.Label(
            bubble,
            text=message,
            font=("Segoe UI", 10),
            bg=bubble_color,
            fg=self.colors["text"],
            justify="left",
            wraplength=530
        ).pack(anchor="w", padx=11, pady=(3, 3))

        tk.Label(
            bubble,
            text=datetime.now().strftime("%I:%M %p"),
            font=("Segoe UI", 8),
            bg=bubble_color,
            fg=self.colors["muted"]
        ).pack(anchor="e", padx=10, pady=(0, 6))

        self.root.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.canvas.yview_moveto(1.0)

    def send_message(self):
        message = self.entry.get().strip()

        if not message:
            self.entry.focus_set()
            return

        self.add_message("user", message)
        self.entry.delete(0, tk.END)

        response = self.chatbot.get_response(message)
        self.add_message("bot", response)
        self.entry.focus_set()

    def send_suggestion(self, question):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, question)
        self.send_message()

    def clear_chat(self):
        for widget in self.messages_frame.winfo_children():
            widget.destroy()

        self.add_message(
            "bot",
            "Chat cleared! Hello again. What would you like to know?"
        )


if __name__ == "__main__":
    root = tk.Tk()
    app = FAQChatbotApp(root)
    root.mainloop()
